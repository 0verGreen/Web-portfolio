<script type="module">
  import { Toast } from 'bootstrap.esm.min.js'

  var myCarousel = document.querySelector('#myCarousel')
var carousel = new bootstrap.Carousel(myCarousel,{
  KeyboardEvent=true
})
</script>